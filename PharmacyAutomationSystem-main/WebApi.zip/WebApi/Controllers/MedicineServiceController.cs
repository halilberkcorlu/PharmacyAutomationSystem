﻿using Dal.DbOps;
using Dal.Entities.Concrete;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Model;

namespace WebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class MedicineServiceController : ControllerBase
    {
            [HttpPost("AddMedicine")]
            public string AddMedicine([FromBody] List<ServiceParameterObject> _data)
            {
                try
                {


                    var medicine = JsonConvert.DeserializeObject<Medicine>(_data.FirstOrDefault(x => x.Key == "_medicine").Value);

                    var medicineDb = MedicineDB.GetInstance();
                    var result = medicineDb.AddMedicine(medicine);
                //addnewmedicine olcak eğer öyle olucaksa public string de öyle yap
                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = result != null ? "Success" : "Error",
                        Message = result != null ? JsonConvert.SerializeObject(result) : "",
                        Status = result != null
                    });
                }
                catch (Exception ex)
                {

                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = "Error",
                        Message = ex.Message + "," + (ex.InnerException != null ? ex.InnerException.ToString() : ""),
                        Status = false

                    });
                }
            }

            [HttpPost("GetMedicineList")]
            public string GetMedicineList()
            {
                try
                {
                    var medicineDb = MedicineDB.GetInstance();
                    var result = medicineDb.GetMedicineList();
                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = result != null ? "Success" : "Error",
                        Message = result != null ? JsonConvert.SerializeObject(result) : "",
                        Status = result != null

                    });
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            [HttpPost("UpdateMedicine")]
            public String UpdateMedicine([FromBody] List<ServiceParameterObject> _data)
            {
                try
                {
                    var medicine = JsonConvert.DeserializeObject<Medicine>(_data.FirstOrDefault(x => x.Key == "_medicine").Value);

                    var medicineDb = MedicineDB.GetInstance();
                    var result = medicineDb.UpdateMedicine(medicine);

                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = result != false ? "Success" : "Error",
                        Message = result != false ? JsonConvert.SerializeObject(result) : "",
                        Status = result != false
                    });
                }
                catch (Exception exc)
                {
                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = "Error",
                        Message = exc.Message + "," + (exc.InnerException != null ? exc.InnerException.ToString() : ""),
                        Status = false
                    });
                }
            }

            [HttpPost("DeleteMedicine")]
            public String DeleteMedicine([FromBody] List<ServiceParameterObject> _data)
            {
                try
                {
                    var medicine = JsonConvert.DeserializeObject<Medicine>(_data.FirstOrDefault(x => x.Key == "_medicine").Value);

                    var medicineDb = MedicineDB.GetInstance();
                    var result = medicineDb.DeleteMedicine(medicine);

                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = result != false ? "Success" : "Error",
                        Message = result != false ? JsonConvert.SerializeObject(result) : "",
                        Status = result != false
                    });
                }
                catch (Exception exc)
                {
                    return JsonConvert.SerializeObject(new ApiResult()
                    {
                        Response = "Error",
                        Message = exc.Message + "," + (exc.InnerException != null ? exc.InnerException.ToString() : ""),
                        Status = false
                    });
                }
            }


        [HttpPost("GetMedicineById")]
        public string GetUserById([FromBody] List<ServiceParameterObject> _data)
        {
            try
            {
                var id = Convert.ToInt32(_data.FirstOrDefault(x => x.Key == "_id").Value);

                var medicineDB = MedicineDB.GetInstance();
                var result = medicineDB.GetMedicineById(id);

                return JsonConvert.SerializeObject(new ApiResult()
                {
                    Response = result != null ? "Success" : "Error",
                    Message = result != null ? JsonConvert.SerializeObject(result) : "",
                    Status = result != null
                });
            }
            catch (Exception ex)
            {
                return JsonConvert.SerializeObject(new ApiResult()
                {
                    Response = "Error",
                    Message = ex.Message + "," + (ex.InnerException != null ? ex.InnerException.ToString() : ""),
                    Status = false
                });
            }
        }
    }
    }

